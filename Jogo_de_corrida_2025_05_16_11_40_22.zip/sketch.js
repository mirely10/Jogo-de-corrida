let xJogador1 = 0;
let xJogador2 = 0;
let focused = true;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  // Limpa o frame anterior (deve vir primeiro!)
  if (focused) {
    background('#D2EBB5');
  } else {
    background('rgb(228,178,178)');
  }

  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaJogador(); // Agora a mensagem será desenhada por cima do fundo
}

function desenhaJogadores() {
  textSize(40);
  text("😎", xJogador1, 100);
  text("🤡", xJogador2, 300);
}

function desenhaLinhaDeChegada() {
  fill('white');
  rect(350, 0, 10, 400);
  fill('black');
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
   rect(350, yAtual, 10, 10);
  }
}

function verificaJogador() {
  // Verifica se algum jogador atingiu a linha de chegada
  if (xJogador1 > 350) {
    fill('black');
    textSize(24);
    text("Jogador 1 venceu! 😎", 50, 200);
    noLoop(); // Para a animação
  } 
  else if (xJogador2 > 350) {
    fill('black');
    textSize(24);
    text("Jogador 2 venceu! 🤡", 50, 200);
    noLoop(); // Para a animação
  }
}

function keyReleased() {
  if (key === 'a') {
    xJogador1 += random(20);
  }
  if (key === 's') {
    xJogador2 += random(20);
  }
}